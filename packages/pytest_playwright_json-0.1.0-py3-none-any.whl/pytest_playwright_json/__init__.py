"""pytest-playwright-json - Generate Playwright-compatible JSON reports from pytest"""

__version__ = "0.1.0"
