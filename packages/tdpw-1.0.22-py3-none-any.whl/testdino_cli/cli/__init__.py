"""CLI module for TestDino"""

__all__ = []
