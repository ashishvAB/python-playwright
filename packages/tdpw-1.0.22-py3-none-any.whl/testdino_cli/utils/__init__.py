"""Utility functions module"""

__all__ = []
